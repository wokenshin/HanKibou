//
// Created by 15197 on 2022/7/12.
//

#ifndef LIBRARY_DIVISION_H
#define LIBRARY_DIVISION_H

int divide(int, int);

#endif //LIBRARY_DIVISION_H

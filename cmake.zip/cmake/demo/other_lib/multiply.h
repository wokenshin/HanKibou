#ifndef LIBRARY_MULTIPLY_H
#define LIBRARY_MULTIPLY_H

int mult(int, int);

#endif //LIBRARY_MULTIPLY_H
